//
//  Weather.swift
//  P9_Le_Baluchon
//
//  Created by Adeline GIROIX on 18/10/2022.
//

import Foundation

struct AllWeather: Codable {
    let weather: [Weather]
    let main: Main
    let dt: Int
    let name: String
}

struct Main: Codable {
    let temp: Double
}

struct Weather: Codable {
    let description, main, icon: String
    let id: Int
}
