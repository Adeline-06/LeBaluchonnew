//
//  Translation.swift
//  P9_Le_Baluchon
//
//  Created by Adeline GIROIX on 18/10/2022.
//

import Foundation

struct Translation: Codable {
    let data: Translations
}

struct Translations: Codable {
    let translations: [Infos]
}

struct Infos: Codable {
    let translatedText: String
    let detectedSourceLanguage: String
}
