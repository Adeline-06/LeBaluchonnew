//
//  xcuserdata.swift
//  P9_Le_Baluchon
//
//  Created by Adeline GIROIX on 18/10/2022.
//

import Foundation



    let googleApiIdKey = "AIzaSyCzWsfb-9ppWE7gV6MvFnbo8F5PQra7tiQ"
    let dataFixerApiIdKey = "07077859366c48a521cfcb72000a0545"
    let openweatherApiIdKey = "f12fbb81ea38f1d62e25f7d49c98b9e1"


