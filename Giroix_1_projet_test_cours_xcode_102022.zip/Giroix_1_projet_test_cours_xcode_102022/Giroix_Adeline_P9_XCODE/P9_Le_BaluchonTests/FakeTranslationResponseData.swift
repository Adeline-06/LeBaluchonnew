//
//  FakeTranslationSessionData.swift
//  P9_Le_BaluchonTests
//
//  Created by Adeline GIROIX on 25/10/2022.
//

import Foundation

class FakeTranslationResponseData {
    
    static let responseOK = HTTPURLResponse(url: URL(string: "http://openclassrooms.com")!, statusCode: 200, httpVersion: nil, headerFields: nil)!
    
    static let responseKO = HTTPURLResponse(url: URL(string: "http://openclassrooms.com")!, statusCode: 500, httpVersion: nil, headerFields: nil)!
    
    class TranslationError: Error {}
    static let error = TranslationError()
    
    static var translationCorrectData: Data {
        let bundle = Bundle(for: FakeTranslationResponseData.self)
        let url = bundle.url(forResource: "Translation", withExtension: "json")
        let data = try! Data(contentsOf: url!)
        return data
    } // static var weatherCorrectData
    
    static let translationIncorrectData = "erreur".data(using: .utf8)!
} // end of FakeTranslationResponseData
