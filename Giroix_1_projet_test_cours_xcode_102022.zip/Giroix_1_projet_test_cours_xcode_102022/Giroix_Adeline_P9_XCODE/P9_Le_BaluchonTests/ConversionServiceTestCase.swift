//
//  ConversionServiceTestCase.swift
//  P9_Le_BaluchonTests
//
//  Created by Adeline GIROIX on 25/10/2022.
//

import Foundation

@testable import P9_Le_Baluchon
import XCTest

final class ConversionServiceTestCase: XCTestCase {
    
    var conversionService: ConversionService!
    
    override func setUp() {
        super.setUp()
        conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionCorrectData, response: FakeConversionResponseData.responseOK, error: nil))
    }
    // MARK: - Network call tests

    func testGetConversionShouldPostFailedCallbackIfError() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: nil, response: nil, error: FakeConversionResponseData.error))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    func testGetConversionShouldPostFailedCallbackIfNoData() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: nil, response: nil, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in

            //Then
            XCTAssertFalse(success)
            XCTAssertNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetConversionShouldPostFailedCallbackIfIncorrectResponse() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionIncorrectData, response: FakeConversionResponseData.responseKO, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetConversionShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionIncorrectData, response: FakeConversionResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    func testGetConversionShouldPostFailedCallbackIfJsonKO() {
        // Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionIncorrectData, response: FakeConversionResponseData.responseKO, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    func testGetConversionShouldPostSuccessCallbackIfNoErrorAndCorrectData() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionCorrectData, response: FakeConversionResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in
            //Then
            XCTAssertTrue(success)
            XCTAssertNotNil(searchRate)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetConversionShouldPostSuccessCallbackIfNoError() {
        //Given
        let conversionService = ConversionService(conversionSession: ConversionURLSessionFake(data: FakeConversionResponseData.conversionCorrectData, response: FakeConversionResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        conversionService.getRates { (success, searchRate) in
            let rate = 1.192897
            let index = 0
            let date = "2021-06-28"
            let euroNumber = 2.0
            let dollarNumber = "2.37"
            let convert = self.conversionService.euroToDollarConvert(euroNumber: euroNumber, index: index)
            // Then
            XCTAssertTrue(success)
            XCTAssertNotNil(searchRate)
            XCTAssertEqual(rate, searchRate!.rates.USD)
            XCTAssertEqual(date, searchRate!.date)
            XCTAssertEqual(self.conversionService.convertDate(date: date), "28-06-2021")
            XCTAssertEqual(convert, dollarNumber)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // MARK: - conversion function tests
    func testConvertUserEntrerConvertedInCorrectString() {
        let result = 1.5
        let stringTaped = conversionService.stringToDouble(textToTransform: "1,5")
        XCTAssertEqual(result, stringTaped)
    }

    func testErrorInFormatOfNumber() {
        let doubleError = 0.0
        let stringError = conversionService.stringToDouble(textToTransform: "t2")
        XCTAssertEqual(doubleError, stringError)
    }
}
