//
//  TranslationServiceTestCase.swift
//  P9_Le_Baluchon
//
//  Created by Adeline GIROIX on 25/10/2022.
//

import Foundation

@testable import P9_Le_Baluchon
import XCTest

final class TranslationServiceTestCase: XCTestCase {
    
    var translationService: TranslationService!
    private let languageIndex = 0
    
    private let textToTranslate = "bonjour"
    
    override func setUp() {
        super.setUp()
        translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationCorrectData, response: FakeConversionResponseData.responseOK, error: nil))
    }
    // MARK: - Network call tests
    
    func testGetTranslationShouldPostFailedCallbackIfError() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: nil, response: nil, error: FakeTranslationResponseData.error))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslationShouldPostFailedCallbackIfNoData() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: nil, response: nil, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslationShouldPostFailedCallbackIfIncorrectResponse() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationIncorrectData, response: FakeTranslationResponseData.responseKO, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslationShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationIncorrectData, response: FakeTranslationResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslationShouldPostFailedCallbackIfJsonKO() {
        // Given
        // Callback dataKO
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationIncorrectData, response: FakeTranslationResponseData.responseKO, error: nil))
        // When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    func testGetTranslationShouldPostSuccessCallbackIfNoErrorAndCorrectData() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationCorrectData, response: FakeTranslationResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            // Then
            XCTAssertTrue(success)
            XCTAssertNotNil(traductedResponse)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslationShouldPostSuccessCallbackIfNoError() {
        //Given
        let translationService = TranslationService(translationSession: TranslationURLSessionFake(data: FakeTranslationResponseData.translationCorrectData, response: FakeTranslationResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        translationService.getTranslation(languageIndex: languageIndex, textToTranslate: textToTranslate) { (success, traductedResponse) in
            let text = "Hello"
            let detectedSourceLanguage = "fr"
            
            // Then
            XCTAssertTrue(success)
            XCTAssertNotNil(traductedResponse)
            XCTAssertEqual(text, traductedResponse!.data.translations[0].translatedText)
            
            XCTAssertEqual(detectedSourceLanguage, traductedResponse!.data.translations[0].detectedSourceLanguage)
            
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    // MARK: - pickerView
    func testSelectedLanguage0() {
        let language = translationService.selectedLanguage(index: 0)
        XCTAssertEqual(language, "en")
    }
    
    func testSelectedLanguage1() {
        let language = translationService.selectedLanguage(index: 1)
        XCTAssertEqual(language, "fr")
    }
    
    func testSelectedLanguage2() {
        let language = translationService.selectedLanguage(index: 2)
        XCTAssertEqual(language, "de")
    }
    
    func testSelectedLanguage3() {
        let language = translationService.selectedLanguage(index: 3)
        XCTAssertEqual(language, "es")
    }
    
    func testSelectedLanguageFalse() {
        let language = translationService.selectedLanguage(index: 9)
        XCTAssertEqual(language, "en")
    }
    
    
}
    

