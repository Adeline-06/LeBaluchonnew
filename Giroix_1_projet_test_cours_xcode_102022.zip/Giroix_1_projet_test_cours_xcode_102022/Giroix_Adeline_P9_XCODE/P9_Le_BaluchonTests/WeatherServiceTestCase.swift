//
//  WeatherServiceTestCase.swift
//  P9_Le_BaluchonTests
//
//  Created by Adeline GIROIX on 24/10/2022.
//

import Foundation

@testable import P9_Le_Baluchon
import XCTest

final class WeatherServiceTestCase: XCTestCase {
    
    var weatherService: WeatherService!
    
    override func setUp() {
        super.setUp()
        weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: FakeWeatherResponseData.weatherCorrectData, response: FakeWeatherResponseData.responseOK, error: nil))
    }
    // MARK: - Network call tests
    
    func testGetWeatherShouldPostFailedCallbackIfError() {
        //Given
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: nil, response: nil, error: FakeWeatherResponseData.error))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "Test") { success, weatherResult in
            
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfNoData() {
        //Given
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: nil, response: nil, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "Test") { success, weatherResult in
            
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfIncorrectResponse() {
        //Given
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: FakeWeatherResponseData.weatherIncorrectData, response: FakeWeatherResponseData.responseKO, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "Test") { success, weatherResult in
            
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: FakeWeatherResponseData.weatherIncorrectData, response: FakeWeatherResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "Test") { success, weatherResult in
            
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfJsonKO() {
        // Given
        // Callback dataKO
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: FakeWeatherResponseData.weatherIncorrectData, response: FakeWeatherResponseData.responseKO, error: nil))
        // When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "New York") { success, weatherResult in
            // Then
            XCTAssertFalse(success)
            XCTAssertNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1)
    }
    
    func testGetWeatherShouldPostSuccessCallbackIfNoErrorAndCorrectData() {
        //Given
        let weatherService = WeatherService(weatherSession: WeatherURLSessionFake(data: FakeWeatherResponseData.weatherCorrectData, response: FakeWeatherResponseData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change")
        weatherService.getWeather(city: "Test") { success, weatherResult in
            // Then
            XCTAssertTrue(success)
            XCTAssertNotNil(weatherResult)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // MARK: - conversion function tests
    func testDateConvert() {
        let dt = 1624869947
        let date = weatherService.convertDate(unix: dt)
        let dateString = "28 juin 2021 à 10:45"
        XCTAssertEqual(date, dateString)
    }
    

}
